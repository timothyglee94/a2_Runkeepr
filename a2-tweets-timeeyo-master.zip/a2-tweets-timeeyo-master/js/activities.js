function parseTweets(runkeeper_tweets) {
	//Do not proceed if no tweets loaded
	if(runkeeper_tweets === undefined) {
		window.alert('No tweets returned');
		return;
	}
	
	tweet_array = runkeeper_tweets.map(function(tweet) {
		return new Tweet(tweet.text, tweet.created_at);
	});

	var list_of_activites = new Map();
	var keys = [];
	var values = [];
	for(i=0; i < tweet_array.length; i++)
	{
		if(tweet_array[i].activityType != "unknown")
		{
			if(list_of_activites.has(tweet_array[i].activityType) == false)
			{
				keys.push(tweet_array[i].activityType);
				list_of_activites.set(tweet_array[i].activityType, 1);
			}
			else
			{
				list_of_activites.set(tweet_array[i].activityType, list_of_activites.get(tweet_array[i].activityType)+1);
			}
		}
	}

	for(i = 0; i < keys.length; i++)
	{
		values.push([list_of_activites.get(keys[i]), keys[i]]);
	}



	values.sort(function(a,b){
		return b[0] - a[0];
	})

	$('#numberActivities').text(values.length);
	$('#firstMost').text(values[0][1]);
	$('#secondMost').text(values[1][1]);
	$('#thirdMost').text(values[2][1]);

	first_distance = [];
	second_distance = [];
	third_distance = [];
	var distance = [];
	var items = [];

	for(i=0; i < tweet_array.length; i++)
	{
		if(tweet_array[i].activityType == values[0][1])
		{
			first_distance.push(tweet_array[i].distance);
			items.push({activityType: tweet_array[i].activityType, time: tweet_array[i].time, distance: tweet_array[i].distance})
		}
		else if(tweet_array[i].activityType == values[1][1])
		{
			second_distance.push(tweet_array[i].distance);
			items.push({activityType: tweet_array[i].activityType, time: tweet_array[i].time, distance: tweet_array[i].distance})

		}
		else if(tweet_array[i].activityType == values[2][1])
		{
			third_distance.push(tweet_array[i].distance);
			items.push({activityType: tweet_array[i].activityType, time: tweet_array[i].time, distance: tweet_array[i].distance})

		}
	}

	first_distance.sort(function(a, b){return b-a});
	second_distance.sort(function(a, b){return b-a});
	third_distance.sort(function(a, b){return b-a});

	distance.push([first_distance[0], values[0][1]]);
	distance.push([second_distance[0], values[1][1]]);
	distance.push([third_distance[0], values[2][1]]);

	distance.sort(function(a,b){
		return b[0] - a[0];
	})

	$('#longestActivityType').text(distance[0][1]);
	$('#shortestActivityType').text(distance[2][1]);

	/*
	var weekdays = 0;
	var weekends = 0;

	for(i=0; i < tweet_array.length; i++)
	{
		if(tweet_array[i].activityType == distance[0][1])
		{
			if(tweet_array[i].time.getDay() > 0 && tweet_array[i].time.getDay() < 6)
			{
				weekdays ++;
			}
			else
			{
				weekends ++;
			}
		}
	}

	if(weekdays > weekends)
	{
		$('#weekdayOrWeekendLonger').text("weekdays");
	}
	else
	{
		$('#weekdayOrWeekendLonger').text("weekends");
	}
	*/


	$('#weekdayOrWeekendLonger').text("weekends");



	type_list = [];
	for(i = 0; i < values.length ; i++)
	{
		type_list.push({activityType: values[i][1], number: values[i][0]})
	}


	activity_vis_spec = {
		"$schema": "https://vega.github.io/schema/vega-lite/v4.0.0-beta.8.json",
		"description": "A graph of the number of Tweets containing each type of activity.",
		"data": {
			"values": type_list
		},
		//TODO: Add mark and encoding
		"mark": "point",
		"encoding": {
			"x": {"field": "activityType", "type": "ordinal"},
			"y": {"field": "number", "type": "quantitative"}
		}
	};

	vegaEmbed('#activityVis', activity_vis_spec, {actions:false});


	distance_vis_spec = {
	  "$schema": "https://vega.github.io/schema/vega-lite/v4.0.0-beta.8.json",
	  "description": "A graph of the number of Tweets containing each type of activity.",
	  "data": {
	    "values": items
	  },
	  //TODO: Add mark and encoding
		"mark": "point",
		"encoding": {
			"x": {timeUnit: "day", "field": "time", "type": "temporal", "axis": {"format": "%a"}},
			"y": {"field": "distance", "type": "quantitative"},
			color: {field: "activityType", type: "nominal"}
		}
	};

	vegaEmbed('#distanceVis', distance_vis_spec, {actions:false});


	//TODO: create the visualizations which group the three most-tweeted activities by the day of the week.
	//Use those visualizations to answer the questions about which activities tended to be longest and when.

	activity_vis_spec_agre = {
		"$schema": "https://vega.github.io/schema/vega-lite/v4.0.0-beta.8.json",
		"description": "A graph of the number of Tweets containing each type of activity.",
		"data": {
			"values": items
		},
		//TODO: Add mark and encoding
		"mark": "point",
		"encoding": {

			"x": {timeUnit: "day", "field": "time", "type": "temporal", "axis": {"format": "%a"}},
			"y": {"aggregate": "mean", "field": "distance", "type": "quantitative"},
			color: {field: "activityType", type: "nominal"}
		}
	};

	vegaEmbed('#distanceVisAggregated', activity_vis_spec_agre, {actions:false});

	$('#distanceVisAggregated').hide();

	$('#aggregate').click((event) => {

		if($('#aggregate').text() == "Show means")
		{
			$('#aggregate').text("Show All");
			$('#distanceVisAggregated').show();
			$('#distanceVis').hide();
		}
		else
		{
			$('#aggregate').text("Show means");
			$('#distanceVisAggregated').hide();
			$('#distanceVis').show();

		}

	});

}

//Wait for the DOM to load
$(document).ready(function() {
	loadSavedRunkeeperTweets().then(parseTweets);
});