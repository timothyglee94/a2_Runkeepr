--Readme document for *author*--

1. How many assignment points do you believe you completed (replace the *'s with your numbers)?

*/10
- 1/1 Tweet dates
- 1/1 Tweet categories
- 1/1 User-written tweets
- 2/2 Determining activity type and distance
- 2/2 Graphing activities by distance
- 1/1 Implementing the search box
- 2/2 Populating the table

2. How long, in hours, did it take you to complete this assignment?

13+ hours 

3. What online resources did you consult when completing this assignment? (list sites like StackOverflow or specific URLs for tutorials, etc.)

https://www.tutorialspoint.com/typescript
https://www.w3schools.com/js
https://hackernoon.com/what-you-should-know-about-es6-maps-dc66af6b9a1e
https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map/keys
https://www.javatpoint.com/javascript-date-getday-method

4. What classmates or other individuals did you consult as part of this assignment? What did you discuss?

N/A


5. Is there anything special we need to know in order to run your code?

No there isn't but my values for "A wide range of activities" are dynamic. (Not hardcoded) 


