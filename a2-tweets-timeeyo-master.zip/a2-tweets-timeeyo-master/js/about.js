function parseTweets(runkeeper_tweets) {
	//Do not proceed if no tweets loaded
	if(runkeeper_tweets === undefined) {
		window.alert('No tweets returned');
		return;
	}

	tweet_array = runkeeper_tweets.map(function(tweet) {
		return new Tweet(tweet.text, tweet.created_at);
	});

	//This line modifies the DOM, searching for the tag with the numberTweets ID and updating the text.
	//It works correctly, your task is to update the text of the other tags in the HTML file!
	$('#numberTweets').text(tweet_array.length);


	var options= { weekday: 'long', month: 'long', day: '2-digit', year: 'numeric'};

	$('#lastDate').text(tweet_array[0].time.toLocaleDateString( 'en-US', options));
	$('#firstDate').text(tweet_array[tweet_array.length-1].time.toLocaleDateString('en-US', options));

	completed = 0;
	live = 0;
	achievement = 0;
	miscellaneous = 0;
	written = 0;
	for(i = 0; i< tweet_array.length; i++)
	{
		if(tweet_array[i].source == "completed_event")
		{
			if(tweet_array[i].written)
			{
				written++;
			}
			completed ++;
		}
		else if(tweet_array[i].source == "live_event")
		{
			live ++;
		}
		else if(tweet_array[i].source == "achievement")
		{
			achievement ++;
		}
		else if(tweet_array[i].source == "miscellaneous")
		{
			miscellaneous ++;
		}
	}

	$('.completedEvents').text(completed);
	$('.liveEvents').text(live);
	$('.achievements').text(achievement);
	$('.miscellaneous').text(miscellaneous);
	$('.written').text(written);

	written= written/completed*100;
	completed = completed/tweet_array.length*100;
	live = live/tweet_array.length*100;
	achievement = achievement/tweet_array.length*100;
	miscellaneous = miscellaneous/tweet_array.length*100;

	$('.completedEventsPct').text(math.format(completed, {notation: 'fixed', precision: 2}) +"%");
	$('.liveEventsPct').text(math.format(live, {notation: 'fixed', precision: 2}) +"%");
	$('.achievementsPct').text(math.format(achievement, {notation: 'fixed', precision: 2}) +"%");
	$('.miscellaneousPct').text(math.format(miscellaneous, {notation: 'fixed', precision: 2}) +"%");
	$('.writtenPct').text(math.format(written, {notation: 'fixed', precision: 2}) +"%");

}

//Wait for the DOM to load
$(document).ready(function() {
	loadSavedRunkeeperTweets().then(parseTweets);
});