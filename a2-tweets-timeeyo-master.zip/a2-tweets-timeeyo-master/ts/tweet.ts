class Tweet {
	private text:string;
	time:Date;

	constructor(tweet_text:string, tweet_time:string) {
        this.text = tweet_text;
		this.time = new Date(tweet_time);//, "ddd MMM D HH:mm:ss Z YYYY"
	}

	//returns either 'live_event', 'achievement', 'completed_event', or 'miscellaneous'
    get source():string {
	    if(this.text.startsWith("Just completed"))
        {
            return "completed_event";
        }
	    else if(this.text.includes("#RKLive"))
        {
            return "live_event";
        }
	    else if(this.text.startsWith("Achieved"))
        {
            return "achievement";
        }
        else
        {
            return "miscellaneous";
        }
    }

    //returns a boolean, whether the text includes any content written by the person tweeting.
    get written():boolean {
	    if(this.text.includes("with @Runkeeper"))
        {
            return false;
        }
	    else
        {
            return true;
        }
        //TODO: identify whether the tweet is written
    }

    get writtenText():string {
        if(!this.written) {
            return "";
        }
        else
        {
            var start_index = this.text.indexOf(" https://");
            return (this.text.substring(0, start_index));
        }
        //TODO: parse the written text from the tweet
    }

    get activityType():string {
        if (this.source != 'completed_event') {
            return "unknown";
        }
        //TODO: parse the activity type from the text of the tweet
        if(this.written)
        {
            if(this.text.includes(" km "))
            {
                var start_index = this.text.indexOf(" km ") + 4;
            }
            else
            {
                var start_index = this.text.indexOf(" mi ") + 4;
            }
            var end_index = this.text.indexOf(" - ");
            if(end_index == -1)
            {
                end_index = this.text.indexOf(" with ");
            }
            return (this.text.substring(start_index, end_index));
        }
        else
        {
            if(this.text.includes(" km "))
            {
                var start_index = this.text.indexOf(" km ") + 4;
            }
            else
            {
                var start_index = this.text.indexOf(" mi ") + 4;
            }
            var end_index = this.text.indexOf(" with @Runkeeper");

            return (this.text.substring(start_index, end_index));
        }
    }

    get distance():number {
        if(this.source != 'completed_event') {
            return 0;
        }
        var distance;
        //TODO: prase the distance from the text of the tweet
        if(this.text.includes(" mi "))
        {
            var end_index = this.text.indexOf(" mi ");
            distance = +this.text.substring(17, end_index);

        }
        else
        {
            var end_index = this.text.indexOf(" km ");
            distance = +this.text.substring(17, end_index);
            distance *= 0.621371192;
        }

        return distance;
    }

    getHTMLTableRow(rowNumber:number):string {
        //TODO: return a table row which summarizes the tweet with a clickable link to the RunKeeper activity
        var start_index = this.text.indexOf("http");
        var end_index = this.text.indexOf(" #Runkeeper");

        var front = this.text.substring(0, start_index);
        var link = this.text.substring(start_index, end_index);
        var end = this.text.substring(end_index);

        var final = "<tr><td>";
        final += rowNumber;
        final += "</td><td>";
        final += this.activityType;
        final += "</td><td>";
        final += front;
        final += "<a href=\""+link+"\">"+link+"</a>";
        final += end;
        final += "</td></tr>";

        return final;
    }
}