function parseTweets(runkeeper_tweets) {
	//Do not proceed if no tweets loaded
	if(runkeeper_tweets === undefined) {
		window.alert('No tweets returned');
		return;
	}

	//TODO: Filter to just the written tweets
	tweet_array = runkeeper_tweets.map(function(tweet) {
		return new Tweet(tweet.text, tweet.created_at);
	});

	written = [];

	for(i = 0; i < tweet_array.length; i++)
	{
		if(tweet_array[i].written == true)
		{
			written.push(tweet_array[i]);
		}
	}
}


function addEventHandlerForSearch() {
	//TODO: Search the written tweets as text is entered into the search box, and add them to the table
	$('#searchText').text('');

	$('#textFilter').keyup(function() {
		$('#tweetTable').text("");
		if(this.value != '') {
			$('#searchText').text(this.value);
			number = 0;
			for (i = 0; i < written.length; i++) {
				if (written[i].text.indexOf(this.value) > 0) {
					number++;
					$('#tweetTable').append(written[i].getHTMLTableRow(number));

				}
			}
			$('#searchCount').text(number);
		}
		else
		{
			$('#searchText').text(this.value);
			$('#searchCount').text(0);
		}
	});

}

//Wait for the DOM to load
$(document).ready(function() {
	addEventHandlerForSearch();
	loadSavedRunkeeperTweets().then(parseTweets);
});